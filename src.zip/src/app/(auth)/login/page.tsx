import LoginPage from "@/components/forms/login/login-form";

export default function SingInRoute() {
  return <LoginPage />;
}