// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyDHcy0dzLUQ7y3rGzrSggSPH0tYvwOuqWY",
  authDomain: "cics-task-management.firebaseapp.com",
  projectId: "cics-task-management",
  storageBucket: "cics-task-management.firebasestorage.app",
  messagingSenderId: "8408950164",
  appId: "1:8408950164:web:547aad1d79a1a6e0d39b81",
  measurementId: "G-4R4Q56DN12"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);