import HelpAndSupport from "./index"

export default function HelpAndSupportPage() {
  return <HelpAndSupport />
}

