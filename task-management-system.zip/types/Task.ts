export interface Task {
  id: number
  name: string
  assignedBy: string
  assignedTo: string
  assignedOn: string
  deadline: string
  status: string
  priority: string
  description: string
  completedOn?: string
}

