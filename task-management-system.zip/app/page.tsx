"use client"

import TasksAdminPage from "@/components/TasksAdminPage"

export default function Home() {
  return <TasksAdminPage />
}

