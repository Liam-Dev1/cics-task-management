import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import type { Task } from "@/types/Task"

interface TaskDetailsProps {
  task: Task
  editingTask: Task | null
  setEditingTask: (task: Task | null) => void
  handleUpdateTask: () => void
  handleReopenTask: (taskId: number) => void
  handleVerifyCompletion: (taskId: number) => void
}

export default function TaskDetails({
  task,
  editingTask,
  setEditingTask,
  handleUpdateTask,
  handleReopenTask,
  handleVerifyCompletion,
}: TaskDetailsProps) {
  return (
    <div className="mt-4 bg-[#e0e0e0] p-4 rounded">
      {editingTask && editingTask.id === task.id ? (
        <>
          <Input
            value={editingTask.name}
            onChange={(e) => setEditingTask({ ...editingTask, name: e.target.value })}
            className="mb-2"
          />
          <Textarea
            value={editingTask.description}
            onChange={(e) => setEditingTask({ ...editingTask, description: e.target.value })}
            className="mb-2"
          />
          <div className="flex justify-end">
            <Button onClick={handleUpdateTask} className="bg-[#8B0000] text-white hover:bg-[#660000]">
              Save Changes
            </Button>
          </div>
        </>
      ) : (
        <>
          {task.completedOn && <div className="text-sm text-gray-600 mb-2">Completed on {task.completedOn}</div>}
          <p className="mb-4">{task.description}</p>
          <div className="flex justify-between">
            <Button variant="outline" className="bg-white">
              Attached File
            </Button>
            <div className="space-x-2">
              <Button
                variant="secondary"
                className="bg-[#444444] text-white hover:bg-[#555555]"
                onClick={() => setEditingTask({ ...task, status: "Reopened" })}
              >
                Edit Task
              </Button>
              {task.status !== "Completed" && (
                <Button
                  variant="secondary"
                  className="bg-[#444444] text-white hover:bg-[#555555]"
                  onClick={() => handleVerifyCompletion(task.id)}
                >
                  Verify Completion of Task
                </Button>
              )}
              {task.status === "Completed" && (
                <Button
                  className="bg-[#8B0000] text-white hover:bg-[#660000]"
                  onClick={() => handleReopenTask(task.id)}
                >
                  Reopen Task
                </Button>
              )}
            </div>
          </div>
        </>
      )}
    </div>
  )
}

