"use client"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Search, Plus, PaperclipIcon } from "lucide-react"
import { useState } from "react"
import { DatePicker } from "@/components/ui/date-picker"

interface Task {
  id: number
  name: string
  assignedBy: string
  assignedTo: string
  assignedOn: Date
  deadline: Date
  status: string
  priority: string
  description: string
  completedOn?: string
}

export default function TasksAdminPage() {
  const [showNewTask, setShowNewTask] = useState(false)
  const [tasks, setTasks] = useState<Task[]>([
    {
      id: 1,
      name: "Take Pictures of Spider-Man",
      assignedBy: "J Jonah Jameson",
      assignedTo: "Peter Parker",
      assignedOn: new Date("2024-10-30"),
      deadline: new Date("2024-11-04"),
      status: "Verifying",
      priority: "High",
      description:
        "Listen here, Parker! I don't pay you to sit around! I need pictures--good pictures of Spider-Man! Not blurry, not half-in-the-shadows, not one of those artsy shots you think look so clever! Give me something with action, something that'll sell papers! And I need it by tonight! Got it?",
      completedOn: "11/03/20",
    },
  ])
  const [editingTask, setEditingTask] = useState<Task | null>(null)
  const [newTask, setNewTask] = useState<Partial<Task>>({
    name: "",
    assignedBy: "J Jonah Jameson",
    assignedOn: new Date(),
    deadline: new Date(),
    description: "",
  })

  const handleAddNewTask = () => {
    if (newTask.name && newTask.assignedBy && newTask.assignedOn && newTask.deadline) {
      setTasks([
        ...tasks,
        {
          ...newTask,
          id: tasks.length + 1,
          assignedTo: "Unassigned",
          status: "New",
          priority: "Medium",
        } as Task,
      ])
      setNewTask({
        name: "",
        assignedBy: "J Jonah Jameson",
        assignedOn: new Date(),
        deadline: new Date(),
        description: "",
      })
      setShowNewTask(false)
    }
  }

  const handleEditTask = (task: Task) => {
    setEditingTask({ ...task, status: "Reopened" })
  }

  const handleUpdateTask = () => {
    if (editingTask) {
      setTasks(tasks.map((t) => (t.id === editingTask.id ? editingTask : t)))
      setEditingTask(null)
    }
  }

  const handleReopenTask = (taskId: number) => {
    setTasks(tasks.map((t) => (t.id === taskId ? { ...t, status: "Reopened", completedOn: undefined } : t)))
  }

  const handleVerifyCompletion = (taskId: number) => {
    setTasks(
      tasks.map((t) =>
        t.id === taskId
          ? {
              ...t,
              status: "Completed",
              completedOn: new Date().toLocaleDateString("en-US"),
            }
          : t,
      ),
    )
  }

  const handleDeleteTask = (taskId: number) => {
    setTasks(tasks.filter((t) => t.id !== taskId))
  }

  return (
    <div className="flex min-h-screen">
      {/* Sidebar */}
      <div className="w-[200px] bg-[#333333] text-white">
        <div className="p-4 flex items-center gap-2">
          <img
            src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-bNAUi8spNxShz859Z7GeDiSEGwxe35.png"
            alt="CICS Logo"
            className="h-8"
          />
          <span className="text-xs">Customer Task Management System</span>
        </div>
        <nav className="py-4">
          <a href="/dashboard" className="block px-6 py-3 text-[15px] hover:bg-[#444444]">
            Dashboard
          </a>
          <a href="/tasks" className="block px-6 py-3 text-[15px] bg-[#444444]">
            Tasks
          </a>
          <a href="/reports" className="block px-6 py-3 text-[15px] hover:bg-[#444444]">
            Reports
          </a>
          <a href="/receivers" className="block px-6 py-3 text-[15px] hover:bg-[#444444]">
            Receivers
          </a>
          <a href="/help" className="block px-6 py-3 text-[15px] hover:bg-[#444444]">
            Help
          </a>
          <a href="/user" className="block px-6 py-3 text-[15px] hover:bg-[#444444]">
            User
          </a>
          <a href="/logout" className="block px-6 py-3 text-[15px] hover:bg-[#444444]">
            Log Out
          </a>
        </nav>
      </div>

      {/* Main Content */}
      <div className="flex-1 bg-white">
        <div className="p-6">
          <div className="flex items-baseline gap-2 mb-6">
            <h1 className="text-[48px] font-normal text-black">Tasks</h1>
            <span className="text-[#8B0000] text-[48px]">Admin</span>
          </div>

          {/* Controls */}
          <div className="flex gap-2 mb-6">
            <div className="relative flex-1">
              <div className="absolute inset-y-0 left-3 flex items-center">
                <Search className="h-4 w-4 text-gray-400" />
              </div>
              <Input
                placeholder="Search Tasks"
                className="pl-10 py-2 bg-[#333333] text-white placeholder:text-gray-400 border-none rounded"
              />
            </div>

            <Select>
              <SelectTrigger className="w-32 bg-[#333333] text-white border-none">
                <SelectValue placeholder="Receiver" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Receivers</SelectItem>
              </SelectContent>
            </Select>

            <Select>
              <SelectTrigger className="w-32 bg-[#333333] text-white border-none">
                <SelectValue placeholder="Filters" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Tasks</SelectItem>
              </SelectContent>
            </Select>

            <Select>
              <SelectTrigger className="w-32 bg-[#333333] text-white border-none">
                <SelectValue placeholder="Sort" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="newest">Newest First</SelectItem>
              </SelectContent>
            </Select>

            <Button className="bg-[#333333] text-white hover:bg-[#444444]">Generate Reports</Button>
          </div>

          {/* Tasks Section */}
          <div>
            <div className="mb-4">
              <h2 className="text-xl mb-2">Tasks</h2>
              <Button
                onClick={() => setShowNewTask(true)}
                className="bg-[#8B0000] text-white hover:bg-[#660000] rounded flex items-center gap-2"
              >
                <Plus className="h-4 w-4" /> Add New Task
              </Button>
            </div>

            {/* Task Table Headers */}
            <div className="mb-4">
              <div className="grid grid-cols-7 gap-4 px-4 py-2 text-sm font-medium text-gray-700">
                <div>Task Name</div>
                <div>Assigned by</div>
                <div>Assigned to</div>
                <div>Assigned on</div>
                <div>Deadline</div>
                <div>Status</div>
                <div>Priority</div>
              </div>
            </div>

            {/* New Task Form */}
            {showNewTask && (
              <div className="bg-[#8B0000] p-4 rounded-lg mb-4">
                <div className="grid grid-cols-[1fr,auto,auto,auto] gap-4 mb-4">
                  <Input
                    placeholder="Insert Task Name Here"
                    className="bg-white"
                    value={newTask.name}
                    onChange={(e) => setNewTask({ ...newTask, name: e.target.value })}
                  />
                  <Select
                    value={newTask.assignedBy}
                    onValueChange={(value) => setNewTask({ ...newTask, assignedBy: value })}
                  >
                    <SelectTrigger className="w-[200px] bg-white">
                      <SelectValue placeholder="J Jonah Jameson" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="J Jonah Jameson">J Jonah Jameson</SelectItem>
                      <SelectItem value="Peter Parker">Peter Parker</SelectItem>
                    </SelectContent>
                  </Select>
                  <DatePicker
                    date={newTask.assignedOn}
                    setDate={(date) => setNewTask({ ...newTask, assignedOn: date })}
                  />
                  <DatePicker date={newTask.deadline} setDate={(date) => setNewTask({ ...newTask, deadline: date })} />
                </div>
                <Textarea
                  placeholder="Add Description Here"
                  className="mb-4 min-h-[120px] bg-white"
                  value={newTask.description}
                  onChange={(e) => setNewTask({ ...newTask, description: e.target.value })}
                />
                <div className="flex justify-between">
                  <Button variant="secondary" className="bg-gray-700 text-white hover:bg-gray-600">
                    <PaperclipIcon className="h-4 w-4 mr-2" /> Attach Files
                  </Button>
                  <Button
                    variant="secondary"
                    className="bg-gray-700 text-white hover:bg-gray-600"
                    onClick={handleAddNewTask}
                  >
                    Assign Task
                  </Button>
                </div>
              </div>
            )}

            {/* Tasks List */}
            {tasks.map((task) => (
              <div key={task.id} className="bg-white border border-gray-200 rounded-lg mb-4 overflow-hidden">
                <div className="grid grid-cols-7 gap-4 px-4 py-3 items-center bg-[#8B0000] text-white">
                  <div>{task.name}</div>
                  <div>{task.assignedBy}</div>
                  <div>{task.assignedTo}</div>
                  <div>{task.assignedOn.toLocaleDateString()}</div>
                  <div>{task.deadline.toLocaleDateString()}</div>
                  <div>
                    <span className="px-2 py-1 text-xs bg-yellow-100 text-yellow-800 rounded-full">{task.status}</span>
                  </div>
                  <div>
                    <span className="px-2 py-1 text-xs bg-red-100 text-red-800 rounded-full">{task.priority}</span>
                  </div>
                </div>

                <div className="p-4">
                  {task.completedOn && (
                    <div className="text-sm text-gray-600 mb-2">Completed on {task.completedOn}</div>
                  )}
                  <p className="text-gray-700 mb-4">{task.description}</p>
                  <div className="flex justify-between">
                    <Button variant="outline" className="border-gray-300">
                      <PaperclipIcon className="h-4 w-4 mr-2" /> Attached File
                    </Button>
                    <div className="space-x-2">
                      <Button
                        variant="secondary"
                        className="bg-gray-700 text-white hover:bg-gray-600"
                        onClick={() => handleEditTask(task)}
                      >
                        Edit Task
                      </Button>
                      {task.status !== "Completed" && (
                        <Button
                          variant="secondary"
                          className="bg-gray-700 text-white hover:bg-gray-600"
                          onClick={() => handleVerifyCompletion(task.id)}
                        >
                          Verify Completion of Task
                        </Button>
                      )}
                      {task.status === "Completed" && (
                        <Button
                          className="bg-[#8B0000] text-white hover:bg-[#660000]"
                          onClick={() => handleReopenTask(task.id)}
                        >
                          Reopen Task
                        </Button>
                      )}
                      <Button variant="destructive" onClick={() => handleDeleteTask(task.id)}>
                        Delete Task
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}

