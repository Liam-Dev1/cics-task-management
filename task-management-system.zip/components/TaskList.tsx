import { Button } from "@/components/ui/button"
import type { Task } from "@/types/Task"
import { Trash2 } from "lucide-react"

interface TaskListProps {
  tasks: Task[]
  onDeleteTask: (taskId: number) => void
}

export default function TaskList({ tasks, onDeleteTask }: TaskListProps) {
  return (
    <div className="bg-white rounded shadow">
      <table className="w-full">
        <thead>
          <tr className="border-b">
            <th className="text-left p-4">Task Name</th>
            <th className="text-left p-4">Assigned by</th>
            <th className="text-left p-4">Assigned to</th>
            <th className="text-left p-4">Assigned on</th>
            <th className="text-left p-4">Deadline</th>
            <th className="text-left p-4">Status</th>
            <th className="text-left p-4">Priority</th>
            <th className="text-left p-4">Actions</th>
          </tr>
        </thead>
        <tbody>
          {tasks.map((task) => (
            <tr key={task.id} className="border-b">
              <td className="p-4">{task.name}</td>
              <td className="p-4">{task.assignedBy}</td>
              <td className="p-4">{task.assignedTo}</td>
              <td className="p-4">{task.assignedOn}</td>
              <td className="p-4">{task.deadline}</td>
              <td className="p-4">
                <span
                  className={`px-2 py-1 rounded-full text-xs ${
                    task.status === "Completed"
                      ? "bg-green-100 text-green-800"
                      : task.status === "Reopened"
                        ? "bg-blue-100 text-blue-800"
                        : task.status === "In Progress"
                          ? "bg-yellow-100 text-yellow-800"
                          : "bg-gray-100 text-gray-800"
                  }`}
                >
                  {task.status}
                </span>
              </td>
              <td className="p-4">
                <span
                  className={`px-2 py-1 rounded-full text-xs ${
                    task.priority === "High"
                      ? "bg-red-100 text-red-800"
                      : task.priority === "Medium"
                        ? "bg-yellow-100 text-yellow-800"
                        : "bg-green-100 text-green-800"
                  }`}
                >
                  {task.priority}
                </span>
              </td>
              <td className="p-4">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => onDeleteTask(task.id)}
                  className="text-red-600 hover:text-red-800"
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}

