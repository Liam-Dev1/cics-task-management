import Link from "next/link"

export default function Sidebar() {
  return (
    <div className="w-[200px] bg-[#333333] text-white">
      <div className="p-4 bg-[#333333] flex items-center gap-2">
        <img
          src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-bNAUi8spNxShz859Z7GeDiSEGwxe35.png"
          alt="CICS Logo"
          className="h-6"
        />
        <span className="text-xs">Customer Task Management System</span>
      </div>
      <nav className="py-4">
        <Link href="/dashboard" className="block px-6 py-3 text-[15px] hover:bg-[#444444]">
          Dashboard
        </Link>
        <Link href="/tasks" className="block px-6 py-3 text-[15px] bg-[#444444]">
          Tasks
        </Link>
        <Link href="/reports" className="block px-6 py-3 text-[15px] hover:bg-[#444444]">
          Reports
        </Link>
        <Link href="/receivers" className="block px-6 py-3 text-[15px] hover:bg-[#444444]">
          Receivers
        </Link>
        <Link href="/help" className="block px-6 py-3 text-[15px] hover:bg-[#444444]">
          Help
        </Link>
        <Link href="/user" className="block px-6 py-3 text-[15px] hover:bg-[#444444]">
          User
        </Link>
        <Link href="/logout" className="block px-6 py-3 text-[15px] hover:bg-[#444444]">
          Log Out
        </Link>
      </nav>
    </div>
  )
}

