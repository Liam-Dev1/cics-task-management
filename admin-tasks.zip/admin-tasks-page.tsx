"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"
import { Trash2, Edit } from "lucide-react"

interface Task {
  id: number
  title: string
  completed: boolean
  reopened: boolean
}

export default function AdminTasksPage() {
  const [tasks, setTasks] = useState<Task[]>([
    { id: 1, title: "Review project proposal", completed: false, reopened: false },
    { id: 2, title: "Update client documentation", completed: true, reopened: false },
    { id: 3, title: "Prepare for team meeting", completed: false, reopened: false },
  ])

  const [newTaskTitle, setNewTaskTitle] = useState("")

  const addTask = () => {
    if (newTaskTitle.trim() !== "") {
      setTasks([...tasks, { id: Date.now(), title: newTaskTitle, completed: false, reopened: false }])
      setNewTaskTitle("")
    }
  }

  const toggleTaskCompletion = (id: number) => {
    setTasks(tasks.map((task) => (task.id === id ? { ...task, completed: !task.completed } : task)))
  }

  const deleteTask = (id: number) => {
    setTasks(tasks.filter((task) => task.id !== id))
  }

  const editTask = (id: number, newTitle: string) => {
    setTasks(tasks.map((task) => (task.id === id ? { ...task, title: newTitle, reopened: true } : task)))
  }

  return (
    <div className="container mx-auto p-4">
      <h1 className="text-2xl font-bold mb-4">Admin Tasks</h1>
      <div className="flex mb-4">
        <Input
          type="text"
          value={newTaskTitle}
          onChange={(e) => setNewTaskTitle(e.target.value)}
          placeholder="Enter new task"
          className="mr-2"
        />
        <Button onClick={addTask}>Add Task</Button>
      </div>
      <ul className="space-y-2">
        {tasks.map((task) => (
          <li key={task.id} className="flex items-center space-x-2 bg-gray-100 p-2 rounded">
            <Checkbox
              id={`task-${task.id}`}
              checked={task.completed}
              onCheckedChange={() => toggleTaskCompletion(task.id)}
            />
            <Label htmlFor={`task-${task.id}`} className={`flex-grow ${task.completed ? "line-through" : ""}`}>
              {task.title}
            </Label>
            {task.reopened && <span className="text-yellow-600 text-sm">Reopened</span>}
            <Button
              variant="outline"
              size="icon"
              onClick={() => {
                const newTitle = prompt("Edit task:", task.title)
                if (newTitle !== null) {
                  editTask(task.id, newTitle)
                }
              }}
            >
              <Edit className="h-4 w-4" />
            </Button>
            <Button variant="destructive" size="icon" onClick={() => deleteTask(task.id)}>
              <Trash2 className="h-4 w-4" />
            </Button>
          </li>
        ))}
      </ul>
    </div>
  )
}

