"use client"

import { useState, useEffect } from "react"
import { Search, Download, Plus } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { Badge } from "@/components/ui/badge"

interface Receiver {
  id: string
  name: string
  role: string
  email: string
  isActive: boolean
}

function formatRole(role: string): string {
  if (role.toLowerCase() === "qa_tester") {
    return "QA Tester"
  }
  return role.charAt(0).toUpperCase() + role.slice(1).replace(/_/g, " ")
}

export default function TaskReceiversPage() {
  const router = useRouter()
  const [receivers, setReceivers] = useState<Receiver[]>([])
  const [searchTerm, setSearchTerm] = useState("")

  useEffect(() => {
    // Load receivers from localStorage on component mount
    const storedReceivers = localStorage.getItem("receivers")
    if (storedReceivers) {
      setReceivers(JSON.parse(storedReceivers))
    }
  }, [])

  useEffect(() => {
    // Save receivers to localStorage whenever it changes
    localStorage.setItem("receivers", JSON.stringify(receivers))
  }, [receivers])

  const filteredReceivers = receivers.filter(
    (receiver) =>
      receiver.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      receiver.role.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  const handleExportCSV = () => {
    const csvContent =
      "data:text/csv;charset=utf-8," +
      "Name,Role,Email,Status\n" +
      receivers.map((r) => `${r.name},${r.role},${r.email},${r.isActive ? "Active" : "Inactive"}`).join("\n")
    const encodedUri = encodeURI(csvContent)
    window.open(encodedUri)
  }

  const handleViewTaskHistory = (id: string) => {
    alert(`Viewing task history for receiver with ID: ${id}`)
  }

  const handleViewReports = (id: string) => {
    alert(`Viewing reports for receiver with ID: ${id}`)
  }

  const handleEdit = (id: string) => {
    router.push(`/receivers/edit/${id}`)
  }

  const handleDeactivate = (id: string) => {
    setReceivers(
      receivers.map((receiver) => (receiver.id === id ? { ...receiver, isActive: !receiver.isActive } : receiver)),
    )
  }

  return (
    <div className="p-4 bg-white min-h-screen">
      <div className="flex justify-between items-center mb-4">
        <h1 className="text-2xl font-bold">Task Receivers</h1>
        <div className="flex space-x-2">
          <Button className="bg-[#812c2d] hover:bg-[#9f393b] text-white" onClick={handleExportCSV}>
            <Download className="mr-2 h-4 w-4" />
            Export CSV
          </Button>
          <Link href="/receivers/add">
            <Button className="bg-[#812c2d] hover:bg-[#9f393b] text-white">
              <Plus className="mr-2 h-4 w-4" />
              Add Receiver
            </Button>
          </Link>
        </div>
      </div>

      <div className="mb-4 flex">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-500" />
          <Input
            type="text"
            placeholder="Search by name or role..."
            className="pl-10 border-gray-300"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
      </div>

      <div className="bg-white rounded border border-gray-200">
        <div className="grid grid-cols-[auto_2fr_1fr_1fr_auto] gap-4 p-3 bg-gray-100 font-medium text-sm border-b">
          <div className="text-center">Profile</div>
          <div>Name</div>
          <div>Role</div>
          <div className="text-center">Status</div>
          <div className="text-center w-[420px]">Actions</div>
        </div>

        {filteredReceivers.length === 0 ? (
          <div className="p-4 text-center text-gray-500">No receivers found</div>
        ) : (
          filteredReceivers.map((receiver) => (
            <div
              key={receiver.id}
              className="grid grid-cols-[auto_2fr_1fr_1fr_auto] gap-4 items-center p-3 border-b hover:bg-gray-50"
            >
              <div className="w-10 h-10 bg-gray-300 rounded-full overflow-hidden">
                <div className="w-full h-full flex items-center justify-center text-gray-600">
                  {receiver.name.charAt(0)}
                </div>
              </div>
              <div className="font-medium">{receiver.name}</div>
              <div>{formatRole(receiver.role)}</div>
              <div className="flex justify-center">
                <Badge
                  variant="outline"
                  className={`${
                    receiver.isActive
                      ? "bg-green-100 text-green-800 border-green-400"
                      : "bg-red-100 text-red-800 border-red-400"
                  }`}
                >
                  {receiver.isActive ? "Active" : "Inactive"}
                </Badge>
              </div>
              <div className="flex justify-end space-x-2 w-[420px]">
                <Button
                  size="sm"
                  className="bg-[#812c2d] hover:bg-[#9f393b] text-white text-xs px-2 py-1 h-8 w-32"
                  onClick={() => handleViewTaskHistory(receiver.id)}
                >
                  View Task History
                </Button>
                <Button
                  size="sm"
                  className="bg-[#812c2d] hover:bg-[#9f393b] text-white text-xs px-2 py-1 h-8 w-28"
                  onClick={() => handleViewReports(receiver.id)}
                >
                  View Reports
                </Button>
                <Button
                  size="sm"
                  className="bg-[#812c2d] hover:bg-[#9f393b] text-white text-xs px-2 py-1 h-8 w-16"
                  onClick={() => handleEdit(receiver.id)}
                >
                  Edit
                </Button>
                <Button
                  size="sm"
                  className="bg-[#812c2d] hover:bg-[#9f393b] text-white text-xs px-2 py-1 h-8 w-24"
                  onClick={() => handleDeactivate(receiver.id)}
                >
                  {receiver.isActive ? "Deactivate" : "Activate"}
                </Button>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  )
}

