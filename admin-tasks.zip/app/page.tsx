import { redirect } from "next/navigation"

export default function Home() {
  // Redirect to receivers page as default
  redirect("/receivers")
}

